//
//  ViewController.swift
//  Contacts
//
//  Created by Nail on 25.04.23.
//

import UIKit
import Firebase
class ViewController: UIViewController {

    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var contactsTableView: UITableView!
    var contactslist = [Contactslist]()
    var ref : DatabaseReference!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        
        
        contactsTableView.delegate = self
        contactsTableView.dataSource = self
        
        ref = Database.database().reference()
        getContacts()
      
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let indeks = sender as? Int
            if segue.identifier == "toDetail" {
                let gidilecekVC = segue.destination as! ShowDetailViewController
                gidilecekVC.kisi = contactslist[indeks!]
                
            }
            
            if segue.identifier == "toUpdate" {
                let gidilecekVC = segue.destination as! DataUpdateViewController
                gidilecekVC.kisi = contactslist[indeks!]
            }
        }
    
    func getContacts() {
        
        ref.child("kisiler").observe(.value,with: { snapshot in
            
            if let incomingdata = snapshot.value as? [String:AnyObject]{
                self.contactslist.removeAll()
                
                for gelenSatirVerisi in incomingdata{
                    if let sozluk = gelenSatirVerisi.value as? NSDictionary {
                        
                        let key = gelenSatirVerisi.key
                        let kisi_ad = sozluk["kisi_ad"] as? String ?? ""
                        let kisi_tel = sozluk["kisi_tel"] as? String ?? ""
                        let kisi_status = sozluk["kisi_status"] as? String ?? ""
                        let kisi_idnumber = sozluk["kisi_idnumber"] as? String ?? ""
                        
                        
                        let kisi = Contactslist(contact_id:key, contact_name:kisi_ad, contact_tel:kisi_tel, contact_status:kisi_status, contact_idnummer:kisi_idnumber)
                        self.contactslist.append(kisi)
                    }
                }
            }else {
                self.contactslist = [Contactslist]()
            }
            DispatchQueue.main.async {
                self.contactsTableView.reloadData()
            }
            
        })
    }
    func searchContacts(aramakelimesi:String) {
        
        ref.child("kisiler").observe(.value,with: { snapshot in
            
            if let incomingdata = snapshot.value as? [String:AnyObject]{
                self.contactslist.removeAll()
                
                for gelenSatirVerisi in incomingdata{
                    if let sozluk = gelenSatirVerisi.value as? NSDictionary {
                        
                        let key = gelenSatirVerisi.key
                        let kisi_ad = sozluk["kisi_ad"] as? String ?? ""
                        let kisi_tel = sozluk["kisi_tel"] as? String ?? ""
                        let kisi_status = sozluk["kisi_status"] as? String ?? ""
                        let kisi_idnumber = sozluk["kisi_idnumber"] as? String ?? ""
                        
                        if kisi_ad.contains(aramakelimesi){
                            let kisi = Contactslist(contact_id:key, contact_name:kisi_ad, contact_tel:kisi_tel, contact_status:kisi_status, contact_idnummer:kisi_idnumber)
                            self.contactslist.append(kisi)
                        }
                       
                    }
                }
            }else {
                self.contactslist = [Contactslist]()
            }
            DispatchQueue.main.async {
                self.contactsTableView.reloadData()
            }
            
        })
    }

}

extension ViewController:UITableViewDelegate,UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contactslist.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let contact = contactslist[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "contactCell", for: indexPath) as! ContactTableViewCell
        
        cell.contactLblCell.text = "\(contact.contact_name!) - \(contact.contact_tel!)"
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: "toDetail", sender: indexPath.row)
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        
        let deleteAction = UITableViewRowAction(style: .default, title: "delete", handler: { (action:UITableViewRowAction,indexPath:IndexPath)-> Void in
            
            let kisi = self.contactslist[indexPath.row]
            
            self.ref.child("kisiler").child(kisi.contact_id!).removeValue()
        })
        
        let updateAction = UITableViewRowAction(style: .normal, title: "update", handler: { (action:UITableViewRowAction,indexPath:IndexPath)-> Void in
            
            
            self.performSegue(withIdentifier: "toUpdate", sender: indexPath.row)
        })
        return [deleteAction,updateAction]
    }

}
extension ViewController:UISearchBarDelegate{
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        if searchText == "" {
            getContacts()
        }else {
            searchContacts(aramakelimesi:searchText)
        }
       
    }
    
}
