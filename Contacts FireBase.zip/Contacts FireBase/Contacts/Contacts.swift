//
//  File.swift
//  Contacts
//
//  Created by Nail on 29.04.23.
//

import Foundation

class Contactslist{
    
    var contact_id:String?
    var contact_name:String?
    var contact_tel:String?
    var contact_status:String?
    var contact_idnumber:String?
    
    init(){
        
    }
    
    init(contact_id: String?, contact_name: String?, contact_tel: String?, contact_status: String?, contact_idnummer: String?) {
        self.contact_id = contact_id
        self.contact_name = contact_name
        self.contact_tel = contact_tel
        self.contact_status = contact_status
        self.contact_idnumber = contact_idnummer
    }
    
}
