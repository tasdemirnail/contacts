//
//  ContactTableViewCell.swift
//  Contacts
//
//  Created by Nail on 29.04.23.
//

import UIKit

class ContactTableViewCell: UITableViewCell {

    @IBOutlet weak var contactLblCell: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
