//
//  DataUpdateViewController.swift
//  Contacts
//
//  Created by Nail on 28.04.23.
//

import UIKit
import Firebase
class DataUpdateViewController: UIViewController {
    var kisi:Contactslist?
    var ref:DatabaseReference!
    @IBOutlet weak var statusLbl: UITextField!
    @IBOutlet weak var idLbl: UITextField!
    @IBOutlet weak var telLbl: UITextField!
    @IBOutlet weak var nameLbl: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        if let k = kisi {
            nameLbl.text = k.contact_name
            telLbl.text = k.contact_tel
            statusLbl.text = k.contact_status
            idLbl.text = k.contact_idnumber
        }
        ref = Database.database().reference()
    }
    
    @IBAction func updateButtonClicked(_ sender: Any) {
        if let k = kisi,let name = nameLbl.text , let tel = telLbl.text , let status = statusLbl.text , let idnumber = idLbl.text{
            updateContact(kisi_id:k.contact_id!,kisi_ad:name,kisi_idnumber:idnumber,kisi_tel:tel,kisi_status:status)
        }
        
    }
    func updateContact(kisi_id:String,kisi_ad:String,kisi_idnumber:String,kisi_tel:String,kisi_status:String){
        
        
        ref.child("kisiler").child(kisi_id).updateChildValues(["kisi_ad":kisi_ad,"kisi_tel":kisi_tel,"kisi_status":kisi_status,"kisi_idnumber":kisi_idnumber])
        
        
    }
 

}
