//
//  AddContactsViewController.swift
//  Contacts
//
//  Created by Nail on 28.04.23.
//

import UIKit
import Firebase
class AddContactsViewController: UIViewController {
    @IBOutlet weak var statusLbl: UITextField!
    var ref : DatabaseReference!
    @IBOutlet weak var nameLbl: UITextField!
    @IBOutlet weak var telLbl: UITextField!
    @IBOutlet weak var idLbl: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        ref = Database.database().reference()
    }
    
    @IBAction func saveButtonClicked(_ sender: Any) {
        if let name = nameLbl.text , let tel = telLbl.text , let status = statusLbl.text , let idnumber = idLbl.text{
            addContact(kisi_ad: name, kisi_idnumber: idnumber, kisi_tel: tel, kisi_status: status)
        }
        func addContact(kisi_ad:String,kisi_idnumber:String,kisi_tel:String,kisi_status:String){
            
            let dict:[String:Any] = ["kisi_id":"","kisi_ad":kisi_ad,"kisi_tel":kisi_tel,"kisi_status":kisi_status,"kisi_idnumber":kisi_idnumber]
            
            let newRef = ref.child("kisiler").childByAutoId()
            newRef.setValue(dict)
            
        }
    }
    
}
