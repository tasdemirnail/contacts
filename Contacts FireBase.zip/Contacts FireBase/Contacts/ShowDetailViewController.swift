//
//  ShowDetailViewController.swift
//  Contacts
//
//  Created by Nail on 28.04.23.
//

import UIKit
import Firebase
class ShowDetailViewController: UIViewController {
    var kisi:Contactslist?
    @IBOutlet weak var statusLbl: UILabel!
    @IBOutlet weak var idLbl: UILabel!
    @IBOutlet weak var telLbl: UILabel!
    @IBOutlet weak var nameLbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        if let k = kisi {
            nameLbl.text = k.contact_name
            telLbl.text = k.contact_tel
            statusLbl.text = k.contact_status
            idLbl.text = k.contact_idnumber
        }
    }
    

   

}
